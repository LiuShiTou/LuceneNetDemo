﻿using Lucene.Net.Analysis;
using NSharp.SearchEngine.Lucene.Analysis.Cjk;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 二元分词
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string kw = txtBox.Text.Trim();
            Analyzer analyzer = new CJKAnalyzer();
            TokenStream tokenStream = analyzer.TokenStream("", new StringReader(kw));
            Lucene.Net.Analysis.Token token = null;
            while ((token=tokenStream.Next())!=null)
            {
                Console.WriteLine(token.TermText());
            }
        }
    }
}
