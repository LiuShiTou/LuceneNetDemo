﻿using Lucene.Net.Analysis;
using Lucene.Net.Analysis.Standard;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 一元分词
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string kw = txtBox.Text.Trim();
            Analyzer analyzer = new StandardAnalyzer();//new StandardAnalyzer(Lucene.Net.Util.Version.LUCENE_20)
            TokenStream tokenStream = analyzer.TokenStream("",new StringReader(kw));
            Lucene.Net.Analysis.Token token = null;
            while ((token = tokenStream.Next())!=null)
            {
                Console.WriteLine(token.TermText());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Analyzer analyzer = new StandardAnalyzer(Lucene.Net.Util.Version.LUCENE_20);
            TokenStream tokenStream = analyzer.TokenStream("", new StringReader("guangzhou huan ying ni,广州欢迎你"));
            Lucene.Net.Analysis.Token token = null;
            while ((token = tokenStream.Next()) != null)
            {
                Console.WriteLine(token.TermText());
            }
        }
    }
}
