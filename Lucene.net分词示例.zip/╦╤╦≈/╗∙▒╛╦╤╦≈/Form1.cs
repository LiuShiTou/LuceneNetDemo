﻿using Lucene.Net.Analysis.PanGu;
using Lucene.Net.Documents;
using Lucene.Net.Index;
using Lucene.Net.Search;
using Lucene.Net.Store;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 基本搜索
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string indexPath = @"C:\Users\Administrator\Desktop\搜索\基本搜索\lucenedir";//注意和磁盘上文件夹的大小写一致，否则会报错。将创建的分词内容放在该目录下。
            FSDirectory directory = FSDirectory.Open(new DirectoryInfo(indexPath), new NativeFSLockFactory());//指定索引文件(打开索引目录) FS指的是就是FileSystem
            bool isUpdate = IndexReader.IndexExists(directory);//IndexReader:对索引进行读取的类。该语句的作用：判断索引库文件夹是否存在以及索引特征文件是否存在。
            if (isUpdate)
            {
                if (IndexWriter.IsLocked(directory))
                {
                    IndexWriter.Unlock(directory);
                }
            }
            IndexWriter writer = new IndexWriter(directory, new PanGuAnalyzer(), !isUpdate, Lucene.Net.Index.IndexWriter.MaxFieldLength.UNLIMITED);//向索引库中写索引。这时在这里加锁。
            
            for (int i = 1; i <= 10; i++)
            {
                string txt = File.ReadAllText(@"C:\Users\Administrator\Desktop\lucenetestsource\" + i + ".txt", System.Text.Encoding.Default);//注意这个地方的编码
                writer.DeleteDocuments(new Term("number", i.ToString()));//删除文档
                Document document = new Document();//表示一篇文档。
                document.Add(new Field("number", i.ToString(), Field.Store.YES, Field.Index.NOT_ANALYZED));

                document.Add(new Field("body", txt, Field.Store.YES, Field.Index.ANALYZED, Lucene.Net.Documents.Field.TermVector.WITH_POSITIONS_OFFSETS));
                writer.AddDocument(document);

            }
            writer.Close();//会自动解锁。
            directory.Close();//不要忘了Close，否则索引结果搜不到
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string indexPath = @"C:\Users\Administrator\Desktop\搜索\基本搜索\lucenedir";
            string kw = "对象";
            FSDirectory directory = FSDirectory.Open(new DirectoryInfo(indexPath), new NoLockFactory());
            IndexReader reader = IndexReader.Open(directory, true);
            IndexSearcher searcher = new IndexSearcher(reader);
            //搜索条件
            PhraseQuery query = new PhraseQuery();
            //Lucene.Net.QueryParsers.MultiFieldQueryParser multiFieldQueryParser = new Lucene.Net.QueryParsers.MultiFieldQueryParser( new string[] { "Title", "Summary" }, new PanGuAnalyzer());
            query.Add(new Term("body", kw));//body中含有kw的文章
            query.SetSlop(100);
            //TopScoreDocCollector是盛放查询结果的容器
            TopScoreDocCollector collector = TopScoreDocCollector.create(1000, true);
            searcher.Search(query, null, collector);//根据query查询条件进行查询，查询结果放入collector容器
            ScoreDoc[] docs = collector.TopDocs(0, collector.GetTotalHits()).scoreDocs;
            this.lstBox.Items.Clear();
            for (int i = 0; i < docs.Length; i++)
            {
                int docId = docs[i].doc;//得到查询结果文档的id（Lucene内部分配的id）
                Document doc = searcher.Doc(docId);//找到文档id对应的文档详细信息
                this.lstBox.Items.Add(doc.Get("number") + "\n");// 取出放进字段的值
                this.lstBox.Items.Add(doc.Get("body") + "\n");
                this.lstBox.Items.Add("-----------------------\n");
            }
        }
    }
}
