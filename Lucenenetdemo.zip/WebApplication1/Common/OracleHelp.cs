﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using WebApplication1.Models;
using Oracle.DataAccess.Client;

namespace WebApplication1.Common
{
    public class OracleHelp
    {

        public static string DBLink = ConfigurationManager.AppSettings["cspsdblink"].ToString();
        public static bool AddToDB(Book book)
        {
            string sql = @"INSERT INTO CITYEXPRESS.BOOK_TEST(ID,TITLE,SUMMARY,ADDTIME) VALUES(:id, :title, :summary, :addtime)";
            OracleCommand cmd = new OracleCommand(sql);
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.Parameters.Add("id", book.id);
            cmd.Parameters.Add("title", book.title);
            cmd.Parameters.Add("summary",book.summary);
            cmd.Parameters.Add("addtime", book.addtime);
            try
            {
                using (OracleConnection conn = new OracleConnection(DBLink))
                {
                    conn.Open();
                    cmd.Connection = conn;
                    cmd.ExecuteNonQuery();
                }
                
            }
            catch(Exception ex)
            {
                return false;
            }

            return true;
        }
        public static Book GetAllBooks()
        {
            Book book = new Book();

            return book;
        }
    }
}