﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Lucene.Net.Search;
using Lucene.Net.Store;
using LN = Lucene.Net;
using WebApplication1.Models;
using Lucene.Net.Analysis.PanGu;
using Lucene.Net.Documents;
using Lucene.Net.Index;
using System.IO;
using Lucene.Net.Search.Function;
using Lucene.Net.Search.Spans;

namespace WebApplication1.Common
{
    public class SearchManager
    {
        public static readonly SearchManager sm = new SearchManager();
        public static readonly string indexPath = HttpContext.Current.Server.MapPath("~/IndexData");
        private static IndexSearcher iSearcher=null;
        /*
        public static IndexSearcher GetIndexSearcher()
        {
            FSDirectory directory = FSDirectory.Open(new DirectoryInfo(indexPath), new NoLockFactory());
            if (iSearcher == null)
            {
                if (!System.IO.Directory.Exists(indexPath))
                    System.IO.Directory.CreateDirectory(indexPath);
                IndexReader reader = IndexReader.Open(directory, true);
                //iSearcher = new IndexSearcher(new RAMDirectory(FSDirectory.Open(new System.IO.DirectoryInfo(indexPath))),true);
                iSearcher = new IndexSearcher(reader);
            }
            
            return iSearcher;
        }
        */
        public static IndexSearcher GetIndexSearcher()
        {
            FSDirectory directory = FSDirectory.Open(new DirectoryInfo(indexPath), new NoLockFactory());
            IndexReader reader = IndexReader.Open(directory, true);
            return new IndexSearcher(reader);
        }
        /// <summary>
        /// 普通查询
        /// </summary>
        /// <param name="keyword">关键字</param>
        /// <returns></returns>
        public static List<Book> NormalSearch(string keyword)
        {
            List<Book> list = new List<Book>();
            LN.QueryParsers.MultiFieldQueryParser multiFieldQueryParser = new LN.QueryParsers.MultiFieldQueryParser(new string[] { "title", "summary" }, new PanGuAnalyzer());// LN.Util.Version
            LN.Search.Query query = multiFieldQueryParser.Parse(keyword);
            //LN.Search.Hits hit = GetIndexSearcher().Search(query);//Hits在Lucenenet3.0中过时
            TopScoreDocCollector collector = TopScoreDocCollector.create(1000, true);
            //GetIndexSearcher().Search(query, null, collector);//Filter过滤
            FSDirectory directory = FSDirectory.Open(new DirectoryInfo(indexPath), new NoLockFactory());
            IndexReader reader = IndexReader.Open(directory, true);
            IndexSearcher searcher= new IndexSearcher(reader);
            #region 普通查询
            searcher.Search(query, null, collector);
            ScoreDoc[] scoreDoc = collector.TopDocs(0, collector.GetTotalHits()).scoreDocs;//打了分的文档document
            #endregion
            #region 单列排序
            //Sort sort = new Sort();
            //SortField sf = new SortField("addtime", SortField.STRING, false);//true降序，默认；false升序
            //sort.SetSort(sf);
            //ScoreDoc[] scoreDoc = searcher.Search(query, null, 100, sort).scoreDocs;//int参数：查询结果中数据的最大条数,为0会报超出索引范围的异常
            #endregion
            #region 多列排序
            //Sort sort = new Sort();
            //SortField addtimesf = new SortField("addtime", SortField.STRING, false);
            //SortField titlesf = new SortField("title", SortField.DOC, false);
            //sort.SetSort(new SortField[] { addtimesf, titlesf });
            //ScoreDoc[] scoreDoc = searcher.Search(query, null, 100, sort).scoreDocs;
            #endregion
            #region 查询函数排序
            //FieldScoreQuery fsq = new FieldScoreQuery("id", FieldScoreQuery.Type.INT);//点击数或下载数来排序
            //CustomScoreQuery csq = new CustomScoreQuery(query, fsq);//FieldScoreQuery继承ValueSourceQuery
            //searcher.Search(csq,collector);
            //ScoreDoc[] scoreDoc = collector.TopDocs(0, collector.GetTotalHits()).scoreDocs;
            #endregion
            #region 过滤
            //TermRangeFilter trf = new TermRangeFilter("addtime", "1bdad205-e2c5-46b5-9f82-754eafb1db1a", "881b39c5-8b44-4936-b9a2-1774b2412e73", true, true);
            //ScoreDoc[] scoreDoc = searcher.Search(query, trf, 100).scoreDocs;
            #endregion
            #region 通配符查询
            //WildcardQuery wq = new WildcardQuery(new Term("id", "*?"));//*?
            //searcher.Search(wq, null, collector);
            //ScoreDoc[] scoreDoc = collector.TopDocs(0, collector.GetTotalHits()).scoreDocs;
            #endregion
            for (int i = 0; i < scoreDoc.Length; i++)
            {
                Book book = new Book();
                int docid = scoreDoc[i].doc;
                //Document doc = GetIndexSearcher().Doc(docid);
                Document doc = searcher.Doc(docid);
                book.id = doc.Get("id");
                book.title = doc.Get("title");
                book.summary = doc.Get("summary");
                book.addtime = doc.Get("addtime");
                string t = WebCommon.GetRedHightLight(keyword, book.title);
                book.title = string.IsNullOrEmpty(t) ? book.title : t;
                string s = WebCommon.GetRedHightLight(keyword, book.summary);
                book.summary = string.IsNullOrEmpty(s) ? book.summary : s;
                string a = WebCommon.GetTimeSpan(DateTime.Now - Convert.ToDateTime(book.addtime));
                book.addtime = a;
                list.Add(book);
            }
            return list;
        }
        /// <summary>
        /// 逻辑查询
        /// </summary>
        /// <param name="keywords">关键字数组</param>
        /// <returns></returns>
        public static List<Book> LogicSearch(string[] keywords)
        {
            List<Book> list = new List<Book>();
            FSDirectory directory = FSDirectory.Open(new DirectoryInfo(indexPath), new NoLockFactory());
            IndexReader reader = IndexReader.Open(directory, true);
            IndexSearcher searcher = new IndexSearcher(reader);
            LN.Search.BooleanQuery bq = new BooleanQuery();
            TopScoreDocCollector collector = TopScoreDocCollector.create(1000, true);
            foreach (string item in keywords)
            {
                Term term = new Term("title", item);
                LN.Search.TermQuery tq = new TermQuery(term);
                bq.Add(tq, BooleanClause.Occur.MUST);//与、非、或
            }
            searcher.Search(bq, null, collector);
            ScoreDoc[] scoreDoc = collector.TopDocs(0, collector.GetTotalHits()).scoreDocs;
            for (int i = 0; i < scoreDoc.Length; i++)
            {
                Book book = new Book();
                int docid = scoreDoc[i].doc;
                //Document doc = GetIndexSearcher().Doc(docid);
                Document doc = searcher.Doc(docid);
                book.id = doc.Get("id");
                book.title = doc.Get("title");
                book.summary = doc.Get("summary");
                book.addtime = doc.Get("addtime");
                string t = WebCommon.GetRedHightLight(keywords, book.title);
                book.title = string.IsNullOrEmpty(t) ? book.title : t;
                string s = WebCommon.GetRedHightLight(keywords, book.summary);
                book.summary = string.IsNullOrEmpty(s) ? book.summary : s;
                string a = WebCommon.GetTimeSpan(DateTime.Now - Convert.ToDateTime(book.addtime));
                book.addtime = a;
                list.Add(book);
            }
            return list;
        }
        /// <summary>
        /// 复合查询
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public static List<Book> CombineSearch(string keyword)
        {
            List<Book> list = new List<Book>();
            FSDirectory directory = FSDirectory.Open(new DirectoryInfo(indexPath));
            IndexReader reader = IndexReader.Open(directory, true);//只读的方式打开
            IndexSearcher searcher = new IndexSearcher(reader);
            TopScoreDocCollector collector = TopScoreDocCollector.create(1000, true);
            LN.Search.BooleanQuery bq = new BooleanQuery();
            LN.Search.Query title = new LN.Search.TermQuery(new Term("title",keyword));
            LN.Search.Query summary = new LN.Search.TermQuery(new Term("summary", keyword));
            bq.Add(title, BooleanClause.Occur.SHOULD);
            bq.Add(summary, BooleanClause.Occur.SHOULD);//或、与、非
            searcher.Search(bq, null, collector);
            ScoreDoc[] scoreDoc = collector.TopDocs(0, collector.GetTotalHits()).scoreDocs;
            for (int i = 0; i < scoreDoc.Length; i++)
            {
                Book book = new Book();
                int docid = scoreDoc[i].doc;
                //Document doc = GetIndexSearcher().Doc(docid);
                Document doc = searcher.Doc(docid);
                book.id = doc.Get("id");
                book.title = doc.Get("title");
                book.summary = doc.Get("summary");
                book.addtime = doc.Get("addtime");
                string t = WebCommon.GetRedHightLight(keyword, book.title);
                book.title = string.IsNullOrEmpty(t) ? book.title : t;
                string s = WebCommon.GetRedHightLight(keyword, book.summary);
                book.summary = string.IsNullOrEmpty(s) ? book.summary : s;
                string a = WebCommon.GetTimeSpan(DateTime.Now - Convert.ToDateTime(book.addtime));
                book.addtime = a;
                list.Add(book);
            }
            return list;
        }
        /// <summary>
        /// 跨度查询
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public static List<Book> SpanSearch(string keyword1,string keyword2)
        {
            List<Book> list = new List<Book>();
            FSDirectory directory = FSDirectory.Open(new DirectoryInfo(indexPath));
            IndexReader reader = IndexReader.Open(directory, true);
            IndexSearcher searcher = new IndexSearcher(reader);
            #region 多线程查询
            //IndexSearcher[] ss = new IndexSearcher[3];
            //for (int i = 0; i < ss.Length; i++)
            //{
            //    ss[i] = new IndexSearcher(directory, true);
            //}
            //ParallelMultiSearcher searcher = new ParallelMultiSearcher(ss);
            #endregion
            TopScoreDocCollector collector = TopScoreDocCollector.create(1000, true);
            SpanNearQuery snq = new SpanNearQuery(new SpanQuery[] { new SpanTermQuery(new Term("title", keyword1)), new SpanTermQuery(new Term("title",keyword2)) },1,true);//跨度<=1
            searcher.Search(snq, null, collector);
            ScoreDoc[] scoreDoc = collector.TopDocs(0, collector.GetTotalHits()).scoreDocs;
            for (int i = 0; i < scoreDoc.Length; i++)
            {
                Book book = new Book();
                int docid = scoreDoc[i].doc;
                //Document doc = GetIndexSearcher().Doc(docid);
                Document doc = searcher.Doc(docid);
                book.id = doc.Get("id");
                book.title = doc.Get("title");
                book.summary = doc.Get("summary");
                book.addtime = doc.Get("addtime");
                string t = WebCommon.GetRedHightLight(keyword1,keyword2, book.title);
                book.title = string.IsNullOrEmpty(t) ? book.title : t;
                string s = WebCommon.GetRedHightLight(keyword1, keyword2, book.summary);
                book.summary = string.IsNullOrEmpty(s) ? book.summary : s;
                string a = WebCommon.GetTimeSpan(DateTime.Now - Convert.ToDateTime(book.addtime));
                book.addtime = a;
                list.Add(book);
            }
            return list;
        }
    }
}