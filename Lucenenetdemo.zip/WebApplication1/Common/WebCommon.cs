﻿using Lucene.Net.Analysis;
using Lucene.Net.Analysis.PanGu;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace WebApplication1.Common
{
    public class WebCommon
    {
        // /创建HTMLFormatter,参数为高亮单词的前后缀
        public static string CreateHightLight(string keywords, string Content)
        {
            PanGu.HighLight.SimpleHTMLFormatter simpleHTMLFormatter =
             new PanGu.HighLight.SimpleHTMLFormatter("<font color=\"red\">", "</font>");
            //创建Highlighter ，输入HTMLFormatter 和盘古分词对象Semgent
            PanGu.HighLight.Highlighter highlighter =
            new PanGu.HighLight.Highlighter(simpleHTMLFormatter,
            new PanGu.Segment());
            //设置每个摘要段的字符数
            highlighter.FragmentSize = 150;
            //获取最匹配的摘要段
            return highlighter.GetBestFragment(keywords, Content);
        }
        public static string GetRedHightLight(string kewords,string content)
        {
            string result = string.Empty;
            //string[] ss = kewords.Split(',').Where(s => s != null).ToArray();
            if (content.Contains(kewords))
                result=content.Replace(kewords, "<font style='color:red;font-weight:blod;'>"+kewords+"</font>");

            return result;
        }
        public static string GetRedHightLight(string[] kewords, string content)
        {
            //string result = string.Empty;
            foreach (string item in kewords)
            {
                if (content.Contains(item))
                    content = content.Replace(item, "<font style='color:red;font-weight:blod;'>" + item + "</font>");
            }
            return content;
        }
        public static string GetRedHightLight(string k1,string k2,string content)
        {
            if (content.Contains(k1))
                content = content.Replace(k1, "<font style='color:red;font-weight:blod;'>" + k1 + "</font>");
            if (content.Contains(k2))
                content = content.Replace(k2, "<font style='color:red;font-weight:blod;'>" + k2 + "</font>");
            return content;
        }
        /// <summary>
        /// 盘古分词
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public static string[] KeyWordPanGu(string keyword)
        {
            List<string> list = new List<string>();
            Analyzer analyzer = new PanGuAnalyzer();
            TokenStream tokenStream = analyzer.TokenStream("", new StringReader(keyword));
            Lucene.Net.Analysis.Token token = null;
            while ((token = tokenStream.Next()) != null)
            {
                list.Add(token.TermText());
            }
            return list.ToArray();
        }
        /// <summary>
        /// 时间梯度
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static string GetTimeSpan(TimeSpan time)
        {
            if (time.TotalDays > 365)
            {
                return Math.Floor(time.TotalDays / 365) + "年前";
            }
            else if (time.TotalDays > 30)
            {
                return Math.Floor(time.TotalDays / 30) + "月前";
            }
            else if (time.TotalHours > 24)
            {
                return Math.Floor(time.TotalDays) + "天前";
            }
            else if (time.TotalHours > 1)
            {
                return Math.Floor(time.TotalHours) + "小时前";
            }
            else if (time.TotalMinutes > 1)
            {
                return Math.Floor(time.TotalMinutes) + "分钟前";
            }
            else
            {
                return "刚刚:";
            }
        }
    }
}