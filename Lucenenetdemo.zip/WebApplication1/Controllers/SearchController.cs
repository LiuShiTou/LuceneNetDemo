﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using WebApplication1.Common;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class SearchController : Controller
    {
        // GET: Search
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Search(string keyword)
        {
            if (string.IsNullOrWhiteSpace(keyword))
                return Content("keyword");

            List<Book> list = SearchManager.NormalSearch(keyword);//普通查询
            //List<Book> list = SearchManager.LogicSearch(WebCommon.KeyWordPanGu(keyword));//逻辑查询
            //List<Book> list = SearchManager.CombineSearch(keyword);//复合查询
            #region 跨度查询
            //string[] kes = WebCommon.KeyWordPanGu(keyword);
            //if (kes.Length < 2)
            //    return Content("不满足跨度查询");
            //List<Book> list = SearchManager.SpanSearch(kes[0],kes[1]);
            #endregion

            if (list.Count <= 0)
                return Content("没有匹配结果");

            //ViewData["books"] = list;

            return Json(list);
        }
        public ActionResult AddIndex()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Add(string title,string summary)
        {
            Book book = new Book();
            book.id = Guid.NewGuid().ToString();
            book.title = title;
            book.summary = summary;
            book.addtime = System.DateTime.Now.ToString();
            if (!OracleHelp.AddToDB(book))
            {
                return Content("FALSE");
            }
            else
            {
                //加入到索引库
                IndexManage.bookIndex.Add(book);

                return Content("OK");
            }
        }
    }
}